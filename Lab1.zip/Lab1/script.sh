#!/bin/bash
find "$3" -xdev -size "+$1" -size "-$2"
